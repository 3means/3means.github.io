---
layout: author
photo: /assets/img/uploads/profile.png
name: thiagorossener
display_name: Thiago Rossener
position: Chief Editor
bio: Just a developer.
github_username: thiagorossener
facebook_username: thiagorossener
twitter_username: thiagorossener
instagram_username: thiagorossener
linkedin_username: thiagorossener
medium_username: thiagorossener
---

